import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import * as ExcelJS from 'exceljs';
import * as fs from 'fs';
import * as path from 'path';
import type { Express } from 'express';
import { PortIronOreInfo } from './entities/port-iron-ore-info.entity';
import { CreatePortIronOreInfoDto } from './dto/create-port-iron-ore-info.dto';
import { UpdatePortIronOreInfoDto } from './dto/update-port-iron-ore-info.dto';
import { PortIronOrePaginationDto } from './dto/pagination.dto';

const SORT_FIELD_MAP: Record<string, string> = {
  name: 'ore.name',
  inventory: 'ore.inventory',
  created_at: 'ore.created_at',
  'composition.TFe': "JSON_EXTRACT(ore.composition, '$.TFe')",
  'composition.价格': "JSON_EXTRACT(ore.composition, '$.价格')",
};

/**
 * ✅ 固定表头（唯一标准）
 * - 查询 / 导入 / 导出 / 前端展示 都以此为准
 * - 注意：composition 中不包含"矿粉名称"和"港口"
 */
export const FIXED_HEADERS = [
  '矿粉名称', '港口',
  'TFe', 'SiO2', 'Al2O3', 'P', 'S', 'MnO', 'H2O',
  '粉率', '车板价', '运费', '干粉价格',
  '厂内筛分搬到等费用', '干基不含税',
  'CaO', 'MgO', 'TiO2', 'Zn', 'K2O', 'Na2O',
  'Cr', 'Cu', 'As', '烧损', 'Ni',
];

type FixedHeader = (typeof FIXED_HEADERS)[number];


@Injectable()
export class PortIronOreInfoService {
  constructor(
    @InjectRepository(PortIronOreInfo)
    private readonly repo: Repository<PortIronOreInfo>,
  ) {}

  /** =========================
   *  核心：规范化 composition（按 FIXED_HEADERS 顺序，排除"矿粉名称"和"港口"）
   * ========================= */
  private normalizeComposition(
    composition?: Record<string, any>,
  ): Record<string, any> {
    const result: Record<string, any> = {};

    FIXED_HEADERS.forEach((key) => {
      if (key === '矿粉名称' || key === '港口') return;
      result[key] = composition?.[key] ?? 0;
    });

    return result;
  }

  /** ========================= 创建 ========================= */
  async create(dto: CreatePortIronOreInfoDto, username: string) {
    const ore = this.repo.create({
      ...dto,
      composition: this.normalizeComposition(dto.composition),
      inventory: dto.inventory ?? 0,
      modifier: username,
      remark: dto.remark ?? '',
    });
    return this.repo.save(ore);
  }

  /** ========================= 更新 ========================= */
  async update(id: number, dto: UpdatePortIronOreInfoDto, username: string) {
    const ore = await this.repo.findOne({ where: { id } });
    if (!ore) throw new NotFoundException(`ID ${id} 不存在`);
    Object.assign(ore, {
      ...dto,
      composition: dto.composition ? this.normalizeComposition(dto.composition) : ore.composition,
      modifier: username,
    });
    return this.repo.save(ore);
  }

  /** ========================= 查询（核心修改点） ========================= */
  async query(params: PortIronOrePaginationDto) {
    const { page = 1, pageSize = 10, name, type, sort, order } = params;
    const qb = this.repo.createQueryBuilder('ore');

    if (name) {
      qb.andWhere('ore.name LIKE :name', { name: `%${name}%` });
    }

    const sortField = sort && SORT_FIELD_MAP[sort]
      ? SORT_FIELD_MAP[sort]
      : 'ore.id';

    qb.orderBy(sortField, order === 'desc' ? 'DESC' : 'ASC');
    qb.skip((page - 1) * pageSize).take(pageSize);

    const [list, total] = await qb.getManyAndCount();

    /**
     * ✅ 规范化 composition，确保按 FIXED_HEADERS 顺序
     * ✅ 统一返回 data 而不是 list
     */
    const mapped = list.map(item => ({
      ...item,
      composition: this.normalizeComposition(item.composition),
    }));

    return { data: mapped, total, page, pageSize, totalPages: Math.ceil(total / pageSize) };
  }

  async remove(ids: number[]) {
    const list = await this.repo.findBy({ id: In(ids) });
    if (!list.length) throw new NotFoundException('数据不存在');
    return this.repo.remove(list);
  }

  /** ========================= 导出 Excel ========================= */
  async exportExcel(): Promise<Buffer> {
    const list = await this.repo.find();
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('港口矿粉');

    // ✅ 按 FIXED_HEADERS 顺序导出
    sheet.addRow(FIXED_HEADERS);

    list.forEach(item => {
      const composition = this.normalizeComposition(item.composition);

      sheet.addRow([
        item.name,
        item.port ?? '未知港口',
        ...FIXED_HEADERS
          .filter(h => h !== '矿粉名称' && h !== '港口')
          .map(h => composition[h]),
      ]);
    });

    return Buffer.from(await workbook.xlsx.writeBuffer());
  }

  /** ========================= 导入 Excel ========================= */
  async importExcel(file: Express.Multer.File, username: string) {
    if (!file?.buffer) throw new BadRequestException('文件为空');

    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(file.buffer as any);
    const sheet = workbook.worksheets[0];
    if (!sheet) throw new BadRequestException('Excel 中没有工作表');

    const headerRow = sheet.getRow(1);
    const headerMap: Record<string, number> = {};

    // ✅ 严格校验表头：每个列名必须在 FIXED_HEADERS 中
    headerRow.eachCell((cell, col) => {
      const val = String(cell.value ?? '').trim();
      if (!val) return;
      if (!FIXED_HEADERS.includes(val as FixedHeader)) {
        throw new BadRequestException(`非法列名：${val}`);
      }
      headerMap[val] = col;
    });

    if (!headerMap['矿粉名称']) {
      throw new BadRequestException('缺少必要列：矿粉名称');
    }

    const result: PortIronOreInfo[] = [];

    sheet.eachRow({ includeEmpty: true }, (row, index) => {
      if (index === 1) return;

      const name = String(row.getCell(headerMap['矿粉名称'])?.value ?? '').trim();
      if (!name) return;

      const port = headerMap['港口']
        ? String(row.getCell(headerMap['港口'])?.value ?? '').trim()
        : '未知港口';

      const composition: Record<string, any> = {};

      // ✅ 遍历 FIXED_HEADERS，缺失列自动补0
      FIXED_HEADERS.forEach(key => {
        if (key === '矿粉名称' || key === '港口') return;
        const col = headerMap[key];
        const val = col ? parseFloat(String(row.getCell(col)?.value ?? '')) : 0;
        composition[key] = Number.isFinite(val) ? val : 0;
      });

      result.push(this.repo.create({
        name,
        port,
        inventory: 0,
        remark: '',
        composition: this.normalizeComposition(composition),
        modifier: username,
      }));
    });

    if (!result.length) {
      return { status: 'error', message: '没有有效数据可导入' };
    }

    await this.repo.save(result);
    return { status: 'success', message: `成功导入 ${result.length} 条数据` };
  }

  /** ========================= 模板 ========================= */
  private readonly templateDir = process.env.TEMPLATE_PATH || './templates';
  private readonly templateFilename = 'port-iron-ore-info-template.xlsx';

  private async ensureTemplateFileExists(): Promise<string> {
    await fs.promises.mkdir(this.templateDir, { recursive: true });
    const filePath = path.join(this.templateDir, this.templateFilename);
    if (fs.existsSync(filePath)) return filePath;

    const workbook = new ExcelJS.Workbook();
    workbook.addWorksheet('模板').addRow(FIXED_HEADERS);
    await workbook.xlsx.writeFile(filePath);
    return filePath;
  }

  async getTemplateFilePath(): Promise<string> {
    return this.ensureTemplateFileExists();
  }

  /** 删除所有原料 */
async removeAll(username: string) {
  try {
    const allRecords = await this.repo.find();
    if (!allRecords.length) {
      return { status: 'error', message: '没有数据可删除' };
    }

    // 可选：记录操作人
    allRecords.forEach(record => {
      record.modifier = username;
    });

    await this.repo.remove(allRecords);

    return { status: 'success', message: `成功删除 ${allRecords.length} 条原料` };
  } catch (error) {
    console.error('removeAll error:', error);
    return { status: 'error', message: '删除失败' };
  }
}

}
