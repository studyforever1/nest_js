import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import axios, { AxiosResponse } from 'axios';
import { Task, TaskStatus } from '../../database/entities/task.entity';
import { Result } from '../../database/entities/result.entity';
import { User } from '../user/entities/user.entity';
import { ApiResponse } from '../../common/response/response.dto';
import { SjconfigService } from '../sj-config/sj-config.service';
import { SjRawMaterial } from '../sj-raw-material/entities/sj-raw-material.entity';
import { v4 as uuidv4 } from 'uuid';
import { appConfig } from '../../config/app.config';

const mainParamUnitMap: Record<string, string> = {
  成本: '成本(元)',
  吨度价: '吨度价',
  干基总消耗: '干基总消耗(t/t)',
  干基总残存: '干基总残存(%)',
  预测烧结烟气含流量: '预测烧结烟气含流量(mg/Nm3)',
};

/** 分页参数 DTO */
export interface PaginationDto {
  page?: number;
  pageSize?: number;
  sort?: string;
  order?: 'asc' | 'desc';
}

/** 内存缓存结构 */
interface TaskCache {
  results: any[];           // 增量结果缓存
  lastUpdated: number;      // 上次更新时间戳
}
/** 根据字段路径取值，比如 '主要参数.成本' 或 '化学成分.TFe' */
function getNestedValue(obj: any, path: string): any {
  return path.split('.').reduce((acc, key) => (acc ? acc[key] : undefined), obj);
}

@Injectable()
export class CalcService {
  private readonly logger = new Logger(CalcService.name);
  private readonly fastApiUrl = appConfig.api.fastApiUrl;

  /** 内存缓存：taskUuid -> TaskCache */
  private taskCache: Map<string, TaskCache> = new Map();

  constructor(
    @InjectRepository(Task) private readonly taskRepo: Repository<Task>,
    @InjectRepository(Result) private readonly resultRepo: Repository<Result>,
    @InjectRepository(User) private readonly userRepo: Repository<User>,
    @InjectRepository(SjRawMaterial) private readonly sjRawMaterialRepo: Repository<SjRawMaterial>,
    private readonly sjconfigService: SjconfigService,
  ) { }

  /** 启动计算任务 */
  /** 启动计算任务（支持 taskUuid 未及时返回 → 初始化中） */


  async startTask(
    moduleName: string,
    user: User,
  ): Promise<ApiResponse<{ taskUuid: string; status: string }>> {
    try {
      this.logger.debug(`准备启动任务，userId=${user.user_id}, module=${moduleName}`);

      /** 1️⃣ NestJS 生成 taskUuid（核心） */
      const taskUuid = uuidv4();

      // ================= 原有参数准备逻辑（几乎不动） =================

      const config = await this.sjconfigService.getLatestConfigByName(user, moduleName);
      if (!config) throw new Error(`未找到模块 ${moduleName} 的配置`);
      console.log('获取到的配置:', config);
      const ingredientData = config.ingredientData || [];

      const ingredientParams: Record<number, any> = {};
      ingredientData.forEach(raw => {
        ingredientParams[raw.id] = {
          ...raw.composition,
          TFe: raw.composition?.TFe ?? 0,
          烧损: raw.composition?.['烧损'] ?? 0,
          价格: raw.composition?.['价格'] ?? 0,
          库存: raw.inventory ?? 0,
        };
      });

      const ingredientLimitsClean: Record<string, any> = {};
      Object.keys(config.ingredientLimits || {}).forEach(id => {
        const { name, ...limits } = config.ingredientLimits[id];
        ingredientLimitsClean[id] = limits;
      });

      const fullParams = {
        calculateType: moduleName,
        ingredientData,
        ingredientParams,
        ingredientLimits: ingredientLimitsClean,
        chemicalLimits: config.chemicalLimits || {},
        otherSettings: config.otherSettings || {},
      };
      console.log('启动任务参数:', fullParams);
      // ================= 2️⃣ 先保存任务（INITIALIZING） =================

      const task = this.taskRepo.create({
        task_uuid: taskUuid,
        module_type: moduleName,
        status: TaskStatus.INITIALIZING,
        parameters: fullParams,
        user,
      });
      await this.taskRepo.save(task);

      // 初始化内存缓存
      this.taskCache.set(taskUuid, { results: [], lastUpdated: Date.now() });

      // ================= 3️⃣ 后台启动 FastAPI（不 await） =================

      this.startFastApiTask(taskUuid, fullParams)
        .catch(err => {
          this.logger.error(`FastAPI 启动失败 task=${taskUuid}: ${err.message}`);
        });

      // ================= 4️⃣ 立即返回给前端 =================

      return ApiResponse.success(
        {
          taskUuid,
          status: 'INITIALIZING',
        },
        '任务已创建，正在启动中',
      );

    } catch (err: unknown) {
      return this.handleError(err, '启动任务失败');
    }
  }

  private async startFastApiTask(taskUuid: string, fullParams: any) {
    try {
      await this.apiPost('/sj/start/', {
        taskUuid,          // ⭐ FastAPI 必须接收这个
        ...fullParams,
      });

      // 启动成功 → RUNNING
      await this.taskRepo.update(
        { task_uuid: taskUuid },
        { status: TaskStatus.RUNNING },
      );
    } catch (err) {
      // 启动失败 → FAILED
      await this.taskRepo.update(
        { task_uuid: taskUuid },
        { status: TaskStatus.FAILED },
      );
      throw err;
    }
  }


  /** 停止任务 */
  async stopTask(taskUuid: string): Promise<ApiResponse<{ taskUuid: string; status: string }>> {
    try {
      const task = await this.findTask(taskUuid);
      if (!task) return ApiResponse.error('任务不存在');

      const res = await this.apiPost('/sj/stop/', { taskUuid });
      if (res.data?.status === 'stopped' || res.status === 200) {
        task.status = TaskStatus.STOPPED;
        await this.taskRepo.save(task);
        this.taskCache.delete(taskUuid);
        return ApiResponse.success({ taskUuid, status: 'stopped' }, '任务已停止');
      }
      return ApiResponse.error(res.data?.message || '停止失败');
    } catch (err: unknown) {
      return this.handleError(err, '停止任务失败');
    }
  }

  /** 查询任务进度（增量返回 + 分页排序 + 总页数） */
  /** 查询任务进度（增量 + 分页排序 + 总页数 + 完成任务返回最终结果） */
  /** 查询任务进度（增量 + 分页排序 + 总页数 + 完成任务返回最终结果） */
  async fetchAndSaveProgress(
    taskUuid: string,
    pagination?: PaginationDto
  ): Promise<ApiResponse<any>> {

    try {

      const task = await this.findTask(taskUuid);

      if (!task) {
        return ApiResponse.success({
          taskUuid,
          status: 'initializing',
          progress: 0,
          total: 0,
          results: [],
          page: pagination?.page ?? 1,
          pageSize: pagination?.pageSize ?? 10,
          totalResults: 0,
          totalPages: 0,
        }, '任务初始化中');
      }

      let results: any[] = [];

      // ================= 🔥 构建原料快照映射 =================
      const ingredientData: any[] = task.parameters?.ingredientData || [];
      const ingredientLimits: Record<string, any> =
        task.parameters?.ingredientLimits || {};
      const chemicalLimits = task.parameters?.chemicalLimits || {};
      const idNameMap: Record<string, string> = {};
      ingredientData.forEach(item => {
        if (item?.id != null && item?.name) {
          idNameMap[String(item.id)] = item.name;
        }
      });
      const idCategoryMap: Record<string, string> = {};

      ingredientData.forEach(item => {
        if (item?.id != null) {
          idCategoryMap[String(item.id)] = item.category || '';
        }
      });
      // ================= 未完成任务 =================
      if (task.status !== TaskStatus.FINISHED) {

        const res = await this.apiGet('/sj/progress/', { taskUuid });
        const { code, message, data } = res.data;

        if (code !== 0 || !data)
          throw new Error(message || 'FastAPI 返回异常');

        if (!Array.isArray(data.results))
          throw new Error('FastAPI 返回 results 不是数组');

        // 过滤有效方案
        const validResults = data.results.filter(item =>
          item &&
          item["主要参数"] &&
          typeof item["主要参数"].成本 === "number" &&
          typeof item["主要参数"].吨度价 === "number"
        );

        // ================= 🔥 合并缓存 =================
        const cache = this.taskCache.get(taskUuid) || {
          results: [],
          lastUpdated: Date.now()
        };

        const combinedMap: Record<string, any> = {};

        // 先加入历史
        cache.results.forEach(item => {
          if (item?.方案序号 != null) {
            combinedMap[String(item.方案序号)] = item;
          }
        });

        // 再加入新结果（覆盖同编号）
        validResults.forEach(item => {
          if (item?.方案序号 != null) {
            combinedMap[String(item.方案序号)] = item;
          }
        });

        results = Object.values(combinedMap);

        // ================= 成本排序 =================
        results.sort((a, b) =>
          a["主要参数"].成本 - b["主要参数"].成本
        );

        results.forEach((item, index) => {
          item.成本排名 = index + 1;
        });

        // ================= 吨度价排序 =================
        [...results]
          .sort((a, b) =>
            a["主要参数"].吨度价 - b["主要参数"].吨度价
          )
          .forEach((item, index) => {
            item.吨度价排名 = index + 1;
          });

        // ================= 名称映射 =================
        results = results.map(item => {

          const mapped: Record<string, any> = { ...item };

          if (item["原料配比"]) {

            const entries = Object.entries(item["原料配比"]);

            // 🔥 分类优先级函数
            const getPriority = (id: string) => {
              const category = idCategoryMap[id] || '';

              if (category.startsWith('T')) return 1;
              if (category.startsWith('X')) return 2;
              if (category.startsWith('R')) return 3;
              if (category.startsWith('F')) return 4;
              return 5;
            };

            // 🔥 排序
            entries.sort(([idA], [idB]) => {

              const pA = getPriority(idA);
              const pB = getPriority(idB);

              if (pA !== pB) return pA - pB;

              const catA = idCategoryMap[idA] || '';
              const catB = idCategoryMap[idB] || '';

              if (catA !== catB) return catA.localeCompare(catB);

              return Number(idA) - Number(idB);
            });

            const newMix: Record<string, any> = {};

            entries.forEach(([code, val]: [string, any], index: number) => {

              if (val?.value != null) {

                const ratio = Number(((val.value ?? 0)).toFixed(2));

                const limits = ingredientLimits[code] || {};

                newMix[code] = {
                  ...val,
                  name:
                    idNameMap[code] ||
                    limits.name ||
                    code,
                  value: ratio,
                  sortIndex: index + 1,
                  low_limit: limits.low_limit ?? null,
                  top_limit: limits.top_limit ?? null
                };
              }

            });

            mapped["原料配比"] = newMix;
          }
          // ================= 化学成分处理 =================
          if (item["化学成分"]) {

            const chemicalSource = item["化学成分"];
            const chemicalWithLimits: Record<string, any> = {};

            Object.keys(chemicalSource).forEach(key => {

              const limits = chemicalLimits[key] || {};
              const val = chemicalSource[key];

              // 🔥 如果已经是完整结构，就不要再包一层
              if (typeof val === 'object' && val !== null && 'value' in val) {

                chemicalWithLimits[key] = {
                  ...val,
                  low_limit: val.low_limit ?? limits.low_limit ?? null,
                  top_limit: val.top_limit ?? limits.top_limit ?? null,
                };

              } else {

                chemicalWithLimits[key] = {
                  value: val,
                  low_limit: limits.low_limit ?? null,
                  top_limit: limits.top_limit ?? null,
                };

              }

            });

            mapped["化学成分"] = chemicalWithLimits;
          }
          // ================= 主要参数加单位 =================
          if (item["主要参数"]) {

            const originalMain = item["主要参数"];
            const newMain: Record<string, any> = {};

            Object.keys(originalMain).forEach(key => {
              const newKey = mainParamUnitMap[key] || key;
              newMain[newKey] = originalMain[key];
            });

            mapped["主要参数"] = newMain;
          }
          return mapped;
        });

        // ================= 更新缓存 =================
        cache.results = results;
        cache.lastUpdated = Date.now();
        this.taskCache.set(taskUuid, cache);

        // ================= 更新任务状态 =================
        task.status =
          data.status === 'finished'
            ? TaskStatus.FINISHED
            : TaskStatus.RUNNING;

        task.progress = data.progress;
        task.total = data.total;

        await this.taskRepo.save(task);

        // ================= 完成任务 → 持久化 =================
        if (task.status === TaskStatus.FINISHED && results.length) {
          await this.saveResults(task, results);

          // 延迟删除缓存，避免闪空
          setTimeout(() => {
            this.taskCache.delete(taskUuid);
          }, 30000);
        }

      } else {

        // ================= 已完成任务 =================
        const cache = this.taskCache.get(taskUuid);

        if (cache?.results?.length) {
          results = cache.results;
        } else {
          const resultEntity =
            await this.resultRepo.findOne({
              where: { task: { task_uuid: taskUuid } }
            });

          results = resultEntity?.output_data || [];
        }
      }

      // ================= 分页 =================
      const {
        pagedResults,
        totalResults,
        totalPages
      } = this.applyPaginationAndSort(results, pagination);

      return ApiResponse.success({
        taskUuid: task.task_uuid,
        status: task.status,
        progress: task.progress,
        total: task.total,
        results: pagedResults,
        page: pagination?.page ?? 1,
        pageSize: pagination?.pageSize ?? 10,
        totalResults,
        totalPages,
      });

    } catch (err: any) {
      // 11️⃣ 异常 fallback → 返回初始化状态
      return ApiResponse.success({
        taskUuid,
        status: 'initializing',
        progress: 0,
        total: 0,
        results: [],
        page: pagination?.page ?? 1,
        pageSize: pagination?.pageSize ?? 10,
        totalResults: 0,
        totalPages: 0,
      }, '任务初始化中');
    }
  }


  /** 分页 + 排序工具方法 */
  private applyPaginationAndSort(results: any[], pagination?: PaginationDto) {
    let sortedResults = results;

    if (pagination?.sort) {
      const fieldPath = pagination.sort; // 支持 '主要参数.成本'、'化学成分.TFe'
      const order = pagination.order === 'desc' ? -1 : 1;

      sortedResults = [...results].sort((a, b) => {
        let va = getNestedValue(a, fieldPath);
        let vb = getNestedValue(b, fieldPath);

        // 转数字排序优先
        const na = Number(va);
        const nb = Number(vb);
        if (!isNaN(na) && !isNaN(nb)) {
          va = na;
          vb = nb;
        } else {
          va = va ? String(va) : '';
          vb = vb ? String(vb) : '';
        }

        return va > vb ? order : va < vb ? -order : 0;
      });
    }

    const page = pagination?.page ?? 1;
    const pageSize = pagination?.pageSize ?? 10;
    const start = (page - 1) * pageSize;
    const pagedResults = sortedResults.slice(start, start + pageSize);

    return {
      pagedResults,
      totalResults: sortedResults.length,
      totalPages: Math.ceil(sortedResults.length / pageSize),
    };
  }


  private async apiPost(path: string, data: any): Promise<AxiosResponse<any>> {
    try {
      return await axios.post(`${this.fastApiUrl}${path}`, data);
    } catch (err: any) {
      throw new Error(err.response?.data?.message || err.message || '接口请求失败');
    }
  }

  private async apiGet(path: string, params: any): Promise<AxiosResponse<any>> {
    try {
      return await axios.get(`${this.fastApiUrl}${path}`, { params });
    } catch (err: any) {
      throw new Error(err.response?.data?.message || err.message || '接口请求失败');
    }
  }

  private async findTask(taskUuid: string, relations: string[] = []): Promise<Task | null> {
    return this.taskRepo.findOne({ where: { task_uuid: taskUuid }, relations });
  }

  private async saveResults(task: Task, results: any[]): Promise<void> {
    const resultEntity = this.resultRepo.create({
      task,
      output_data: results,
      is_shared: false,
      finished_at: new Date(),
    });
    await this.resultRepo.save(resultEntity);
  }

  private mapStatus(status: string): TaskStatus {
    return status === 'finished' ? TaskStatus.FINISHED : TaskStatus.RUNNING;
  }

  private handleError(err: unknown, prefix = '操作失败'): ApiResponse<any> {
    const message = err instanceof Error ? err.message : String(err);
    this.logger.error(`${prefix}: ${message}`, (err as any)?.stack);
    return ApiResponse.error(message);
  }
  async getSchemeByIndex(
    taskUuid: string,
    index: number
  ): Promise<any | null> {

    const resultEntity = await this.resultRepo.findOne({
      where: { task: { task_uuid: taskUuid } },
    });

    if (!resultEntity) return null;

    let allResults: any[] = [];

    if (Array.isArray(resultEntity.output_data)) {
      allResults = resultEntity.output_data;
    } else if (typeof resultEntity.output_data === 'string') {
      try {
        allResults = JSON.parse(resultEntity.output_data);
      } catch (err) {
        this.logger.error(`解析 output_data 出错: ${err}`);
        return null;
      }
    }

    const scheme = allResults.find(
      item => item['方案序号'] === index
    );

    if (!scheme) return null;

    // 🔥 只做排序
    const chemicalOrder = [
      'TFe',
      'SiO2',
      'CaO',
      'MgO',
      'Al2O3',
      'P',
      'S',
      'TiO2',
      'K2O',
      'Na2O',
      'Zn',
      'As',
      'Pb',
      'V2O5',
      'R2',
      '镁铝比',
    ];

    const source = scheme['化学成分'] || {};
    const sortedChemical: Record<string, any> = {};

    // 按固定顺序排
    chemicalOrder.forEach(key => {
      if (source.hasOwnProperty(key)) {
        sortedChemical[key] = source[key];
      }
    });

    // 补充没定义顺序的字段
    Object.keys(source).forEach(key => {
      if (!sortedChemical.hasOwnProperty(key)) {
        sortedChemical[key] = source[key];
      }
    });

    return {
      ...scheme,
      '化学成分': sortedChemical
    };
  }

  /** 导出单个方案为 Excel，并整理所需参数 */
  async exportSchemeExcel(taskUuid: string, index: number) {
    // 1️⃣ 获取方案信息
    const scheme = await this.getSchemeByIndex(taskUuid, index);
    if (!scheme) throw new Error('方案不存在');

    const ingredientWithLimits = scheme['原料配比'] || {};
    const mainParams = scheme['主要参数'] || {};
    const chemical = scheme['化学成分'] || {};

    // 2️⃣ 获取任务参数（用于 其他费用）
    const task = await this.taskRepo.findOne({
      where: { task_uuid: taskUuid },
    });

    // 3️⃣ 获取原料 ID 列表
    const ingredientIds = Object.keys(ingredientWithLimits).map(Number);

    // 4️⃣ 查询原料基础信息
    const rawMaterials = await this.sjRawMaterialRepo.find({
      where: { id: In(ingredientIds) },
    });

    // 5️⃣ 组装 ingredientParams（FastAPI 需要的结构）
    const ingredientParams: Record<string, any> = {};

    for (const id of ingredientIds) {
      const val = ingredientWithLimits[id];
      const raw = rawMaterials.find(r => r.id === id);

      if (!raw) continue;

      ingredientParams[val.name] = {
        原料产地: raw.origin || '',
        分类编号: raw.category || '',
        H2O: raw.composition?.H2O ?? 0,
        价格: raw.composition?.价格 ?? 0,
        lose_index: val.lose_index ?? 1,
        配比: Number(val.value) || 0,
      };
    }

    // 6️⃣ 组装 otherSettings（FastAPI 用）
    const finalOtherSettings = {
      ...scheme.otherSettings,
      ...mainParams,
      导出名称: `${taskUuid}-${index}`,
      其他费用: task?.parameters?.['otherSettings']["其他费用"] ?? 0,
      干基总残存: mainParams['干基总残存'] ?? 0,
      品位: chemical?.TFe?.value ?? 0,
    };
    console.log("导出参数", finalOtherSettings);
    return {
      ingredientParams,
      otherSettings: finalOtherSettings,
    };
  }

  /** 调用 FastAPI 生成 Excel */
  async callFastApi(payload: { ingredientParams: any; otherSettings: any }) {
    const response = await axios.post(`${this.fastApiUrl}${'/sj/export/excel/'}`, payload, { responseType: 'arraybuffer' });
    return Buffer.from(response.data);
  }

  /** 调用 FastAPI 生成 Excel buffer */


}
