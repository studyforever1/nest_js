import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import * as ExcelJS from 'exceljs';
import * as fs from 'fs';
import * as path from 'path';
import type { Express } from 'express';

import { PelletEconInfo } from './entities/pellet-econ-info.entity';
import { CreatePelletEconInfoDto } from './dto/create-pellet-econ-info.dto';
import { UpdatePelletEconInfoDto } from './dto/update-pellet-econ-info.dto';
import { ConfigGroup } from 'src/database/entities/config-group.entity';
import { User } from '../user/entities/user.entity';

/**
 * ✅ 固定表头（唯一标准）
 * - 查询 / 导入 / 导出 / 前端展示 都以此为准
 * - 根据数据库实际数据提取的composition字段（不包含name、港口等基础字段）
 */
export const FIXED_HEADERS = [
  'TFe','SiO2','Al2O3','P', 'S', 'MnO', 'H2O', '粉率', '车板价','运费', '干粉价格', '干基不含税到厂价',
  'CaO','MgO','TiO2','Zn','K2O','Na2O','Cr','Cu','As','Ni','烧损'
];

type FixedHeader = (typeof FIXED_HEADERS)[number];

/** 排序字段映射 */
const SORT_FIELD_MAP: Record<string, string> = {
  // 普通字段
  name: 'p.name',
  created_at: 'p.created_at',
  // JSON 字段
  'composition.TFe': "JSON_EXTRACT(p.composition, '$.TFe')",
  'composition.干基不含税到厂价': "JSON_EXTRACT(p.composition, '$.干基不含税到厂价')",
};

@Injectable()
export class PelletEconInfoService {
  private readonly SORT_FIELD_MAP = SORT_FIELD_MAP;

  constructor(
    @InjectRepository(PelletEconInfo)
    private readonly repo: Repository<PelletEconInfo>,
  ) {}

  /** =========================
   *  核心：规范化 composition
   * 注意：港口字段为字符串类型，其他字段为数字类型
   * ========================= */
  private normalizeComposition(
    composition?: Record<string, any>,
  ): Record<string, any> {
    const result: Record<string, any> = {};
    FIXED_HEADERS.forEach((key) => {
      if (key === '港口') {
        result[key] = composition?.[key] ?? '未知港口';
      } else {
        result[key] = composition?.[key] ?? 0;
      }
    });
    return result;
  }

  /** ========================= 创建 ========================= */
  async create(dto: CreatePelletEconInfoDto, username: string) {
    return this.repo.save(
      this.repo.create({
        ...dto,
        composition: this.normalizeComposition(dto.composition),
        modifier: username,
        enabled: true,
      }),
    );
  }

  /** ========================= 更新 ========================= */
  async update(id: number, dto: UpdatePelletEconInfoDto, username: string) {
    const entity = await this.repo.findOne({ where: { id } });
    if (!entity) throw new NotFoundException('数据不存在');
    Object.assign(entity, dto, {
      composition: dto.composition ? this.normalizeComposition(dto.composition) : entity.composition,
      modifier: username,
    });
    return this.repo.save(entity);
  }

  /** ========================= 查询（核心修改点） ========================= */
async query(options: {
  user: User;
  page?: number;
  pageSize?: number;
  name?: string;
  sort?: string;
  order?: 'asc' | 'desc';
}) {
  const { user, page = 1, pageSize = 10, name, sort, order } = options;

  // ================= 1️⃣ 构建查询 =================
  const qb = this.repo.createQueryBuilder('p');

  if (name) {
    qb.andWhere('p.name LIKE :name', { name: `%${name}%` });
  }

  if (sort) {
    if (sort.startsWith('composition.')) {
      const key = sort.replace('composition.', '');
      qb.orderBy(
        `CAST(JSON_EXTRACT(p.composition, '$."${key}"') AS DECIMAL)`,
        order === 'desc' ? 'DESC' : 'ASC'
      );
    } else if (this.SORT_FIELD_MAP[sort]) {
      qb.orderBy(
        this.SORT_FIELD_MAP[sort],
        order === 'desc' ? 'DESC' : 'ASC'
      );
    } else {
      qb.orderBy('p.id', 'ASC');
    }
  } else {
    qb.orderBy('p.id', 'ASC');
  }

  // ❗不在SQL分页
  const records = await qb.getMany();
  const total = records.length;

  // ================= 2️⃣ 获取用户最新配置 =================
  let selectedSet = new Set<number>();

  try {
    const group = await this.repo.manager
      .getRepository(ConfigGroup)
      .createQueryBuilder('cg')
      .leftJoin('cg.user', 'user')
      .leftJoin('cg.module', 'module')
      .where('user.user_id = :userId', { userId: user.user_id })
      .andWhere('module.name = :moduleName', {
        moduleName: '外购球团块矿经济性评价',
      })
      .orderBy('cg.updated_at', 'DESC')
      .getOne();

    if (group?.config_data) {
      const configData =
        typeof group.config_data === 'string'
          ? JSON.parse(group.config_data)
          : group.config_data;

      const pelletParams: number[] =
        configData.pelletParams ?? configData.ingredientParams ?? [];

      selectedSet = new Set(pelletParams.map(id => Number(id)));
    }
  } catch (err) {
    console.warn('获取用户球团块矿配置失败', err);
  }

  // ================= 3️⃣ 映射 =================
  const mapped = records.map(item => ({
    ...item,
    composition: this.normalizeComposition(item.composition),
    selected: selectedSet.has(Number(item.id)),
  }));

  // ================= 4️⃣ 已选优先 =================
  const mappedSorted = mapped.sort((a, b) =>
    a.selected === b.selected ? 0 : a.selected ? -1 : 1
  );

  // ================= 5️⃣ 内存分页 =================
  const start = (page - 1) * pageSize;
  const end = start + pageSize;
  const paged = mappedSorted.slice(start, end);

  return {
    data: paged,
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

  async remove(ids: number[]) {
    if (!ids?.length) throw new Error('未提供删除 ID');

    const list = await this.repo.findBy({ id: In(ids) });
    if (!list.length) throw new NotFoundException(`ID ${ids.join(',')} 不存在`);

    return this.repo.remove(list);
  }

  async removeAll(username: string) {
    const list = await this.repo.find();
    if (!list.length) return { status: 'error', message: '球团经济性库为空' };

    list.forEach(i => (i.modifier = username));
    await this.repo.remove(list);

    return { status: 'success', message: `成功删除 ${list.length} 条记录` };
  }

  /** ========================= 导出 Excel ========================= */
  async exportExcel(): Promise<Buffer> {
    const list = await this.repo.find();
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('球团块矿信息库');

    sheet.addRow(['矿粉名称', ...FIXED_HEADERS]);

    list.forEach(item => {
      const composition = this.normalizeComposition(item.composition);
      sheet.addRow([
        item.name,
        ...FIXED_HEADERS.map(h => composition[h]),
      ]);
    });

    return Buffer.from(await workbook.xlsx.writeBuffer());
  }

  /** ========================= 导入 Excel ========================= */
  async importExcel(file: Express.Multer.File, username: string) {
    if (!file?.buffer) throw new BadRequestException('文件为空');

    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(file.buffer as any);
    const sheet = workbook.worksheets[0];
    if (!sheet) throw new BadRequestException('Excel 中没有工作表');

    const headerRow = sheet.getRow(1);
    const headerMap: Record<string, number> = {};

    headerRow.eachCell((cell, col) => {
      const val = String(cell.value ?? '').trim();
      if (!val) return;
      if (!FIXED_HEADERS.includes(val as FixedHeader) && val !== '矿粉名称') {
        throw new BadRequestException(`非法列名：${val}`);
      }
      headerMap[val] = col;
    });

    if (!headerMap['矿粉名称']) {
      throw new BadRequestException('缺少必要列：矿粉名称');
    }

    const result: PelletEconInfo[] = [];

    sheet.eachRow({ includeEmpty: true }, (row, index) => {
      if (index === 1) return;

      const name = String(row.getCell(headerMap['矿粉名称'])?.value ?? '').trim();
      if (!name) return;

      const composition: Record<string, any> = {};

      FIXED_HEADERS.forEach(key => {
        const col = headerMap[key];
        let val: any = 0;
        if (col !== undefined && row.getCell(col)) {
          const cellVal = row.getCell(col).value;
          if (key === '港口') {
            // 港口字段为字符串类型，缺失时默认"未知港口"
            val = cellVal !== null && cellVal !== undefined && cellVal !== '' ? String(cellVal).trim() : '未知港口';
          } else {
            // 其他字段为数字类型，缺失时默认0
            if (cellVal !== null && cellVal !== undefined && cellVal !== '') {
              const num = parseFloat(String(cellVal).trim());
              val = Number.isFinite(num) ? num : 0;
            }
          }
        } else {
          // 列不存在时，港口字段默认"未知港口"，其他字段默认0
          val = key === '港口' ? '未知港口' : 0;
        }
        composition[key] = val;
      });

      result.push(this.repo.create({
        name,
        composition,
        modifier: username,
        enabled: true,
      }));
    });

    if (!result.length) {
      return { status: 'error', message: '没有有效数据可导入' };
    }

    await this.repo.save(result);
    return { status: 'success', message: `成功导入 ${result.length} 条数据` };
  }

  /** ========================= 模板 ========================= */
  private readonly templateDir = process.env.TEMPLATE_PATH || './templates';
  private readonly templateFilename = 'pellet-econ-info-template.xlsx';

  private async ensureTemplateFileExists(): Promise<string> {
    await fs.promises.mkdir(this.templateDir, { recursive: true });
    const filePath = path.join(this.templateDir, this.templateFilename);
    if (fs.existsSync(filePath)) return filePath;

    const workbook = new ExcelJS.Workbook();
    workbook.addWorksheet('模板').addRow(['矿粉名称', ...FIXED_HEADERS]);
    await workbook.xlsx.writeFile(filePath);
    return filePath;
  }

  async getTemplateFilePath(): Promise<string> {
    return this.ensureTemplateFileExists();
  }
}
